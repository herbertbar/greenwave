
"""
main.py - Entry point for GreenWave Ticketing System
Run: python main.py
"""
import sys
from src.gui import GreenWaveApp

def main():
    app = GreenWaveApp()
    app.mainloop()

if __name__ == "__main__":
    main()
